<script>
	import { onMount } from 'svelte';
	onMount(() => window.location.replace('/'));
</script>
