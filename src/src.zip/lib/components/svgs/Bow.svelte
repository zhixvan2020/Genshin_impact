<svg
	viewBox="0 0 128 128"
	version="1.1"
	xmlns="http://www.w3.org/2000/svg"
	xmlns:xlink="http://www.w3.org/1999/xlink"
	xml:space="preserve"
	style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:1.5;"
>
	<g transform="matrix(0.94442,0,0,0.94442,4.27757,-0.4701)">
		<g transform="matrix(1.05885,-0,-0,1.05885,-4.52931,0.497767)">
			<use
				xlink:href="#_ImageBow1"
				x="20.069"
				y="20.019"
				width="45.409px"
				height="45.382px"
				transform="matrix(0.987158,0,0,0.986573,0,0)"
			/>
		</g>
	</g>
	<g transform="matrix(0.94442,0,0,0.94442,4.27757,-0.4701)">
		<g transform="matrix(1.05885,-0,-0,1.05885,-4.52931,0.497767)">
			<use
				xlink:href="#_ImageBow2"
				x="39.941"
				y="60.407"
				width="68.523px"
				height="48.243px"
				transform="matrix(0.993092,0,0,0.984541,0,0)"
			/>
		</g>
	</g>
	<g transform="matrix(0.954497,0,0,0.954497,4.40699,-0.764803)">
		<g transform="matrix(1.04767,-0,-0,1.04767,-4.61708,0.801263)">
			<use
				xlink:href="#_ImageBow3"
				x="72.762"
				y="44.826"
				width="17.055px"
				height="17.055px"
				transform="matrix(0.947507,0,0,0.947507,0,0)"
			/>
		</g>
	</g>
	<g transform="matrix(0.667805,-0.667805,0.667805,0.667805,-24.1918,61.0036)">
		<path
			d="M4,64L7,67L10,64L7,61L10,58L12,60L19.942,60L22,58L30,66L100,66L102,64L100,62L105,57L128,68.934L105,80.868L100,75.868L102,73.868L100,71.868L30,71.868L22,79.868L20,78L12,78L10,80L7,77L10,73.868L7,70.868L4,73.868L-1,68.934L4,64Z"
			style="fill:rgb(255,253,255);stroke:rgb(125,129,134);stroke-width:1.06px;"
		/>
	</g>
	<defs>
		<image
			id="_ImageBow1"
			width="46px"
			height="46px"
			xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAuCAYAAABXuSs3AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAFJUlEQVRogdWYS2wbRRjH/9/MxGsndRLbaZun0qRNQ+IEyVQp9ElLERceKvTAAYTgUvXCBQmkWtpaG6urilIOcOCCxAUJhITgiEQrHgda0VatkFLaRGrjtKlKorzIw7G9M8OhSaidNLbzsNPfbXd25vvp8+zs54+wzpiWLQA0AtjJOW9jjNUBCCitKpRUZQBo7lGttf40Ggn/lMu6Yh1ECUAH5/wIMQpJR9a6XK5Upa8Sfr/f4/F4YLgNuA03XIYLBIKGxs2/b6pYfyyQa5w1EZ+T7eScv6i1PmQYhqirrzM2b97MKioqIEpE1jic87xirkrctGw3ER0jojcNw+D1DfXu2rpa5vV6V7NsTqxI3LRsg4iOEtE7VVVVvLWt1aioqFhrt2XJS9y0bBcRvUpE7/oDftHW3uYutPA8OYublt3JOOv2VfrcbcE2d2Vl5Xp6ZSWruGnZxBh7i4jeDu0KGdXV1YXwysqy4qZll3PBrVJP6VNdz3YZpaWlhfLKymPFTcsOMsZONzQ0lLYH20sYY4X0ysqS4pHomTeI6HjomZBRXbMxtkYmi8RNy36Jc358/8H9RllZWTGcciLt9zctu4tz/sHefXs3tDTwSMZNy25ljEV3P7fb8Jav/5dvpcwVbS+IuYs6xti50K6QEQjkXOcUBc75CSnlMWZato9z/ll7sN1TU1NTbK9lMS17DzF6BQAYF/xcU3NT+bambRvrvMvAtOwtjDGzq6vLAAAhHdnYsrOl6NJEBMbYa9322T1LjSulana07HD5A34AWb6cWmuMjIxgYnwCo6Oj8Xg8rlYj5/f7RUdnh7HUWHNzM/P7/VsAbFlqnHOOQNX/799jxePxOC7/eXl2ZnpmXGt9VUrZA+AfAHqF3vWpZOpER2fHkoOG28DW6q1ZF9H6YfglxcfHxnHxj4tJrfU3Sqmvo5HwqjINAKZlT612jUdZJC6lxJUrVxJSyk+ikfD5tQy2lix6Kft6+xwn5fwF4EIRfHImTVwrjf47/cpxnM+jkfBK93JBSBMfHh4GgAfRSPhucXRyJ018aGjIcRxnQ2+RedLEJycnkwAGiuSSF2ni09PTADBYHJX8WBDXWiMxmzDwhIgvnOPJRBJElOo+dXKmmEK5spBxpRWIyCmmTD6kn+NaF71KzJUFUVpoUz8ZPDEZzmTNG/vLkUqlSvp6+/KawxhD47ZGiIwWeyHFB6WU3/Xe6s0rJhG9HAgENlX60pus+XRrmzjnR+evpZQ/RCPh/lznRyPhGQBf5vr8PN322f0ANmXez1lcCPF+TW1NyOv1YmBgwJmanLoFoD9fkbUiJ3HTsquUUp3BYBCiRODe3XtJAEPr7AYA0Fqrnp6ehMvlevgv7GGx7VmuW1sKwE9Ee4jove07titRIiClxOTkpAHgRiHEHcc5MzY6Vp9x+1/BOY/Pzs6Wcc6hlPJYpz/+Xkrp1Vpzl8uVLC8v18GOoGe+LTc2NgYu+GAk/FFBSoNoJHwDSyRJENGl+4P3D7fsbGH7DuwjIYTfbbhR4ioBAHfmhN5bvQkl1c8FcF4W5jjOj7dv304lZhPw+Xzwer3z0ouI9cf0xPjEsFLq2wJ7LoL//uuFoYOHjhiD9wZba+tqReZBP8/U1BSuXr6alFJ+GI2ERwrsuQgOAL/9cv7agecP81gs1ialZIILIiIopTAxMYHYnZi8fu26A+CL7lMnLxXZGQDSKyvTsls5568T0dNKKZ/WWnDBH2ilb0gpv4pGwg+KJZrJf37ysujOFyKWAAAAAElFTkSuQmCC"
		/>
		<image
			id="_ImageBow2"
			width="69px"
			height="49px"
			xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEUAAAAxCAYAAACMPmT+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAIeElEQVRogdVaS29bxxX+5nF5ST1ISnIkwZZdF0ij2JHTNm0SKF0URZG2QOp9dl102VUMpIkZ0zTDgHGA/IHs+loEWbTdNYsWKdDAbqLKFhAjktXGjhxLikQ9TJH3Xt47ry5EynpQlPmU8gEEL2fmnjPzzZkzh2eGJNNZmxDyVwCMUloihPiEEA+AA8AxMAWjTVEplQdQBFCpc7d9V549AEEmlTD4BoMDiBBC2Is/f9GSUlpSyF4pJaSUEFJAis1nKSWEEEoEQgohlBDCCCkgpSRKKqKU4kopBgCpzFVBCCmVPxXSisaYotY6r7UuYCex1Yj2MqmEPCxSQpRSbVkWLMsCIjXbs/JnX2itIYSwpZS2lDImpdxBbJlcs0WwFFoIYcptiFKKKaWY1ppffvNtSQgJKKXbrdcFUNRab2itC8aYAva32sVMKhE0TEq9L+4HSils24Zt27WakbJuvl8DYwyUUlxKyaWQXVLKvmoWLITQQjy0Ximk8TyPB0FgA3gPwPv1jmGTFEaPnA8ghIBzDs45EK7ZlAIIVX7kcjlMTkz6lNE/aKU/aEQ3BxBitOaK+MZgZnpG3fniTklrfTmTStxoVE5l+Rw5S6kXhUIBZUJ+lUklVpuRVVk+eyqklFjJrcCgM3z19PSgt7e34feNMaCUOunk600RAtRYPstLy5i6OVVgnH3RrJKDoJWOxePx4fEfjdfe+zqETVIYI9UqGWO3L1989dV2dyKZzr5gjEm0W8+joiYpjSKZzjIA5wFYu6puZVKJ6VbqagcqPmWvU2kOg5TS35w8dXKrwHM9sr6+/hmAV1qsq+Voi6UAAGNMnnv63FaE8WD9AT759ydDrdbTDlRIabWl7EEkEoFSqq+dOrTW0StvvXOhGRnGmOWOkRKyQ9Bah5LpbDiTSpRaLb+npwdnnzob1lqfb1SGUgqzt2cFJ4TYnSCFEIKQHfIDPxgEcK/V8imlOP3t003JEEJg9vYsoYSQMGOdCfMj4YgGMNgRZQ2AYNO1UkJJmLZ886mOru4uBuDIOltjDAAYSkDsTpHS3d1tE0KGO6KsAfiBD8posaPLp6urizDORjqirAH4JR+U0AccQNOWkkxnCYBhAI8TQkYZZ9+nlO6JfSKRCAjI8aaUtRG+7wPAKgeBXe1f8n5IprMcwGkAjzPGzlBKn5JSnmSMmWgsqvr7+sOxeIz29e0NScKRMIwxj1URG6ytrUU+/NuHfmPDAWKxGMZfGK+Z7jsIrutCaz3PAdj7JZmMMaFkOvs0gO9wzscAjCqlBm3b9mPxGOnv749Eo1FEY9GD0o8ANi1FShlNprNkV8Z/EsDLUshGI+vhwkbhnQbf3cLa2pqnlJrmMNXzKdziUEqN9fT0vB3vi/O+vr5QNBZFNBoFY6yrEaWcczDGtFIqDmC9Ul4mKNfoYMrW2zTyD/IA8F8OwKpmKYODg3jp/EsUQEME7AfbtoXrukPYRspRgBACQRBYAOaoMcaqx6c0i0hXBDiCAVw+nwfnfCGTSihqYKxOxSkA0BXpsnAESVnJrWit9SQAcBjwVsYpxhh4ngfXceE4DhzH0cVCseQ4DjzPC5Wjxpb/IWwW97+67yul/gEA3Jj6LUVKCcdx4LouXMdFsVgMioWicFyHBn5gM8YcSumygflKCnkXwDyABQCLAPJH7ay5UChACCEBfA5sksJ3O1pjDEqlElzHheu6cIqOLhQLvlN0tOd5ltaaMsbWCCGLWusvlVL3sDnoBQBfX7n0Wt1HlYeJhfkFDeCjymRxYwydm5uD4ziiWCgGrusS3/fDhJASY2wZwH0p5R1jzPbZXku98dsjNdvNoLx0/l75zRljH83eni0ppebwcLYX37x88cit+3ZgI78B3/cVgFuVMn7l0mtvHV6XDh8z0zO+Meb97X6uc3vxEcRGfgMrKyvKGPPn7eUtCY/rRTKdtQGcBXASQC6TSlw/jH5MT0/7xpg/ZVIJb3t5x0gppxd+alnWy1LKb3V3dweRSMRaX19fAdBxUvL5PFZXVpUx5i+76zpCSjKdjXPOL1qW9d2xc2P2wLEBcM55+SzoUHaxmc9nfAPzx2onC20nJZnOPkkpfXfk5Ih95uyZrehZa43l5WUIIVqRdKor5bC8tIzV1dXA6L1WArSZlGQ6Sxljb4ydG+vefoS69PUSbkzeECCYB/BxC1QN2bb9SFfUSl4JNyZv+OWLPVWTWu22lPFIJDKwnRClFKampnyl1KVMKvGfFul5or+/P3RQI2MMJj6d8LXWH2RSian92rV1SyaEjA4ND+1Iyc19OWeMNp+1kBBwzsfjffEDJ3hmekY6jnNHa/27mvJa1bGqwjl/ore3dwfx+Xw+kFL+q1U6kunszzjno8dP1HZNuVwOd+/cLWmtL2VSiZpLra2WYmA8rXfq9zxPAWj6ChYAJNPZHzLGLjz7/LN2rfRHqVTC5MSkr7VOZVKJtYPkttVSlFTznrcjLkKpVAKaJCWZzg4yxn5NGf3xMz94xo7FYvu2dRwH1z6+VgnSHunGZFtJMcbcWlxYdEefHN3K8wZ+wAAcOFsVJNPZMIDjAE4AGLEs6ydKqdMnRk6YM2fPhCxr92Wph8g/yOP6teu+1vq9dPL1qttvNbR795lwXVctLS1haGjzCFlrbVFKf5/KXD0oaDMAiNbaDofDpe7ubvRGe0MDAwN8aHgIByXGVnIrmPh0wldKXc2kEv+sp9Mtv8G0G8l0doxS+u5zzz9nH3vsGIQQ0OrgkKJyVdW2bRBSXzcX5hcwdXOqpLVOZFKJm/X2ue2kAEAynf0epfTqyMkReurUKaunt6fugT4q7s3d09OfTzta6wuZVOJ/jcjoCCkAkExnhymlv6SU/kJKGW+XbsZYTin1SiaVWGxUxv8B+XJAkUvqrDgAAAAASUVORK5CYII="
		/>
		<image
			id="_ImageBow3"
			width="18px"
			height="18px"
			xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAW0lEQVQ4je3UsQ2AMBBDURs5XcYKa1HQMBBlbqx0RDoKlAVyElV+71eax3nd7p4RiGSTu+eyFyhpCulPh1XLAgAlQZqDRltovaAFLeh3SMB3BbONrUg2qxY+theCJRmnxjtu3QAAAABJRU5ErkJggg=="
		/>
	</defs>
</svg>
